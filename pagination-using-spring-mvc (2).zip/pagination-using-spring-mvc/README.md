# pagination-using-spring-mvc
Implementing basic Pagination using Spring MVC and Hibernate
I have implemented Spring web application without using XML Config files. All the Conigurations in this project is Java configuration.
